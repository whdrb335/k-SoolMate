package project.k_SoolMate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KSoolMateApplication {

	public static void main(String[] args) {
		SpringApplication.run(KSoolMateApplication.class, args);
	}

}
