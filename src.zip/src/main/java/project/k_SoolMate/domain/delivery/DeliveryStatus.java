package project.k_SoolMate.domain.delivery;

public enum DeliveryStatus {
    READY, //배송 준비
    SHIPPED, //배송 출발
    DELIVERED //배송 완료
}
