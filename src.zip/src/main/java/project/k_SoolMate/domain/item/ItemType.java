package project.k_SoolMate.domain.item;

public enum ItemType {
    SOOL
}
