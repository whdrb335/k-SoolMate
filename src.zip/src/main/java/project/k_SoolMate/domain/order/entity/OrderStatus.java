package project.k_SoolMate.domain.order.entity;

public enum OrderStatus {
    ORDER,CANCEL
}
