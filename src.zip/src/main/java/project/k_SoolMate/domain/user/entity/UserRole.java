package project.k_SoolMate.domain.user.entity;

public enum UserRole {
    ADMIN,USER
}
