package project.k_SoolMate.domain.user.entity;

public enum UserStatus {
    ACTIVE,DELETE
}
