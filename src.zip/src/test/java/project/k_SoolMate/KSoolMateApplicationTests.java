package project.k_SoolMate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KSoolMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
